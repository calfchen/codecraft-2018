#ifndef __ROUTE_H__
#define __ROUTE_H__

#include "lib_io.h"

void predict_server(char * info[MAX_INFO_NUM], char * data[MAX_DATA_NUM], int data_num, char * filename);

	

#endif

#!/bin/bash

rm -rf bin build
rm ecs.tar.gz
./build.sh
